/************************************************************************
*************************************************************************
@Name :       	BackToTop - jQuery Plugin
@Revison :    	1.0
@Date : 		12/2011
@Author:     	ALPIXEL AGENCY - (www.myjqueryplugins.com - www.alpixel.fr)
@Support:    	FF, IE7, IE8, MAC Firefox, MAC Safari
@License :		Open Source - MIT License : http://www.opensource.org/licenses/mit-license.php
 
**************************************************************************
*************************************************************************/
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('(4($){$.3={l:{g:\'N J I\',f:G,n:A,r:\'z\',d:\'9\'},i:4(5){1=$.x({},$.3.l,5),$.3.m();c(1.f)$(w).F(4(){c($(u).q()!=0){k(1.d){8\'p\':2.v(\'7\');6;8\'9\':2.y(\'7\');6;s:2.o()}}B{k(1.d){8\'p\':2.C(\'7\');6;8\'9\':2.D(\'7\');6;s:2.E()}}});$(\'#3\').t(4(e){e.H();$(\'b,j\').K({q:0},1.n,1.r)})},m:4(){2=$(\'<a />\',{L:\'3\',M:\'#b\',j:\'<h>\'+1.g+\'</h>\'}).O(\'b\');c(!1.f)2.o()}};3=4(5){$.3.i(5)}})(P);',52,52,'|opts|divBack|BackToTop|function|options|break|fast|case|slide||body|if|appearMethod||autoShow|text|span|init|html|switch|defaults|_constructLink|timeEffect|show|fade|scrollTop|effectScroll|default|click|this|fadeIn|window|extend|slideDown|linear|500|else|fadeOut|slideUp|hide|scroll|true|preventDefault|top|to|animate|id|href|Back|prependTo|jQuery'.split('|'),0,{}))